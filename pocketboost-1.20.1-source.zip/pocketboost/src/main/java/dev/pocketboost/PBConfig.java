package dev.pocketboost;

import net.minecraftforge.common.ForgeConfigSpec;

public final class PBConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue GOVERNOR_ENABLED;
    public static final ForgeConfigSpec.IntValue TARGET_FPS;
    public static final ForgeConfigSpec.DoubleValue ENTITY_FLOOR;
    public static final ForgeConfigSpec.BooleanValue PROFILER_ENABLED;
    public static final ForgeConfigSpec.IntValue PROFILE_SECONDS;
    public static final ForgeConfigSpec.IntValue GC_WARN_PERCENT;
    public static final ForgeConfigSpec.BooleanValue SCHED_ENABLED;
    public static final ForgeConfigSpec.BooleanValue PIN_MAIN;
    public static final ForgeConfigSpec.IntValue NICE_WORKERS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("governor");
        GOVERNOR_ENABLED = b.comment("Lower entity render distance (never below the floor) while frames miss the target; restore it when they recover.")
                .define("enabled", true);
        TARGET_FPS = b.comment("Frame rate you consider smooth.").defineInRange("targetFps", 30, 10, 120);
        ENTITY_FLOOR = b.comment("Lowest entity distance scaling the governor may use (vanilla steps are 0.25).")
                .defineInRange("entityFloor", 0.5, 0.5, 5.0);
        b.pop();
        b.push("profiler");
        PROFILER_ENABLED = b.comment("Log GC share and the busiest thread groups.").define("enabled", true);
        PROFILE_SECONDS = b.defineInRange("intervalSeconds", 30, 10, 600);
        GC_WARN_PERCENT = b.comment("Warn when GC eats more than this percent of wall time.").defineInRange("gcWarnPercent", 10, 1, 90);
        b.pop();
        b.push("scheduler");
        SCHED_ENABLED = b.comment("big.LITTLE scheduling (see README).").define("enabled", true);
        PIN_MAIN = b.comment("Pin Render thread and Server thread to the big cores.").define("pinMainThreads", true);
        NICE_WORKERS = b.comment("Nice value added to background workers (0 = leave them alone, 19 = lowest priority).").defineInRange("workerNice", 6, 0, 19);
        b.pop();
        SPEC = b.build();
    }

    private PBConfig() {}
}
