package dev.pocketboost;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

@Mod(PocketBoost.MODID)
public class PocketBoost {
    public static final String MODID = "pocketboost";
    public static final Logger LOG = LogUtils.getLogger();

    public PocketBoost() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PBConfig.SPEC, "pocketboost.toml");
        try {
            PhoneProfile.init();
        } catch (Throwable t) {
            LOG.warn("[PocketBoost] CPU topology probe failed, continuing: {}", t.toString());
        }
        try {
            Profiler.start();
        } catch (Throwable t) {
            LOG.warn("[PocketBoost] profiler failed to start, continuing: {}", t.toString());
        }
        if (FMLEnvironment.dist.isClient()) {
            try {
                CoreScheduler.start();
            } catch (Throwable t) {
                LOG.warn("[PocketBoost] scheduler failed to start, continuing: {}", t.toString());
            }
            MinecraftForge.EVENT_BUS.register(new ClientGovernor());
        }
    }
}
