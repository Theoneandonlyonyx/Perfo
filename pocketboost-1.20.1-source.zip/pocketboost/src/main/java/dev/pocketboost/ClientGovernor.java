package dev.pocketboost;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Keeps frames on target by trimming entity render distance in 0.25 steps (cheap, no chunk reload, no shader change)
 * and handing it back once frames are comfortably early. Restores your own value on world exit.
 */
public final class ClientGovernor {
    private static final double STEP = 0.25;
    private double original = -1, lastSet = -1, ewmaMs = 33;
    private long lastNanos;
    private int tick, over, under;

    @SubscribeEvent
    public void onFrame(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START) return;
        long now = System.nanoTime();
        if (lastNanos != 0) {
            double ms = (now - lastNanos) / 1e6;
            if (ms < 500) ewmaMs += (ms - ewmaMs) * 0.05;
        }
        lastNanos = now;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null || mc.isPaused()) return;
            if (!PBConfig.GOVERNOR_ENABLED.get()) { restore(mc); return; }
            if (++tick < 40) return;
            tick = 0;

            OptionInstance<Double> opt = mc.options.entityDistanceScaling();
            double cur = opt.get();
            if (original < 0 || (lastSet >= 0 && Math.abs(cur - lastSet) > 1e-6)) { original = cur; lastSet = cur; } // first run, or user changed it
            double floor = Math.min(original, PBConfig.ENTITY_FLOOR.get());
            double targetMs = 1000.0 / PBConfig.TARGET_FPS.get();

            if (ewmaMs > targetMs * 1.15) {
                under = 0;
                if (++over >= 2 && cur - STEP >= floor - 1e-9) { set(opt, cur - STEP); over = 0; }
            } else if (ewmaMs < targetMs * 0.80) {
                over = 0;
                if (++under >= 5 && cur + STEP <= original + 1e-9) { set(opt, cur + STEP); under = 0; }
            } else {
                over = under = 0;
            }
        } catch (Throwable t) {
            PocketBoost.LOG.debug("[PocketBoost] governor tick failed: {}", t.toString());
        }
    }

    @SubscribeEvent
    public void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        restore(Minecraft.getInstance());
        original = lastSet = -1;
        over = under = tick = 0;
    }

    private void set(OptionInstance<Double> opt, double v) {
        opt.set(v);
        lastSet = v;
        PocketBoost.LOG.info("[PocketBoost] entity distance -> {} ({} ms/frame avg)", v, String.format("%.1f", ewmaMs));
    }

    private void restore(Minecraft mc) {
        if (original > 0 && mc.options != null) {
            OptionInstance<Double> opt = mc.options.entityDistanceScaling();
            if (Math.abs(opt.get() - original) > 1e-6) opt.set(original);
            lastSet = original;
        }
    }
}
