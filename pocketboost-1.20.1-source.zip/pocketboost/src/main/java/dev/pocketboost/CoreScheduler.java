package dev.pocketboost;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * big.LITTLE scheduling for phones, done with the Android shell tools every app may use on its own threads.
 *  - "Render thread" and "Server thread" are pinned to the big cores, so the kernel can never park them on a
 *    little A55 core in the middle of a frame or a tick.
 *  - Background workers (chunk building, world-gen pool, ForkJoin, FastLaunch/fastloading pools) get a higher
 *    nice value, so when all 8 cores are busy the frame and the tick win instead of losing to a worker.
 * Nothing is persistent: it all resets when the game process exits. Fails closed: 3 failed passes and it stops.
 */
public final class CoreScheduler {
    private static final String[] DEMOTE = {
            "Worker-Main", "ForkJoinPool", "FastLaunch-Shared", "fastloading-", "Chunk Render", "Chunk Build", "IO-Worker", "Download-"
    };
    private static final Set<String> applied = new HashSet<>();
    private static String bigMaskHex;
    private static int failures, passes;
    private static boolean disabled;

    public static void start() {
        if (PhoneProfile.bigCpus.length == 0 || PhoneProfile.allowed < 4) {
            PocketBoost.LOG.info("[PocketBoost] scheduler: no big/little split found, not starting");
            return;
        }
        long mask = 0;
        for (int c : PhoneProfile.bigCpus) mask |= 1L << c;
        bigMaskHex = Long.toHexString(mask);
        ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "PocketBoost-Sched");
            t.setDaemon(true);
            return t;
        });
        ses.scheduleWithFixedDelay(() -> {
            try { pass(); } catch (Throwable t) { fail("exception: " + t); }
        }, 20, 5, TimeUnit.SECONDS);
    }

    private static void pass() throws Exception {
        if (disabled) return;
        boolean enabled, pin;
        int nice;
        try {
            enabled = PBConfig.SCHED_ENABLED.get();
            pin = PBConfig.PIN_MAIN.get();
            nice = PBConfig.NICE_WORKERS.get();
        } catch (Throwable t) { return; } // config not loaded yet
        if (!enabled) return;

        File[] tasks = new File("/proc/self/task").listFiles();
        if (tasks == null) { fail("cannot list /proc/self/task"); return; }

        StringBuilder script = new StringBuilder();
        int n = 0;
        for (File t : tasks) {
            if (n >= 64) break;
            String tid = t.getName();
            String comm = readComm(new File(t, "comm"));
            if (comm == null) continue;
            String key = tid + ":" + comm;
            if (applied.contains(key)) continue;
            if (pin && (comm.equals("Render thread") || comm.equals("Server thread"))) {
                script.append("taskset -p ").append(bigMaskHex).append(' ').append(tid).append(" 2>&1;");
            } else if (nice > 0 && isDemoted(comm)) {
                script.append("renice -n ").append(nice).append(" -p ").append(tid).append(" 2>&1;");
            } else {
                continue;
            }
            applied.add(key);
            n++;
        }
        if (n == 0) return;

        Process p = new ProcessBuilder("/system/bin/sh", "-c", script.toString()).redirectErrorStream(true).start();
        if (!p.waitFor(15, TimeUnit.SECONDS)) { p.destroyForcibly(); fail("shell timed out"); return; }
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        String low = out.toLowerCase();
        if (low.contains("not found") || low.contains("not permitted") || low.contains("permission denied") || low.contains("invalid")) {
            fail(out.length() > 400 ? out.substring(0, 400) : out);
            return;
        }
        passes++;
        if (passes <= 3) {
            PocketBoost.LOG.info("[PocketBoost] scheduler pass {}: {} thread(s) adjusted, big mask 0x{}. shell said: {}",
                    passes, n, bigMaskHex, out.length() > 500 ? out.substring(0, 500) : out);
        }
    }

    private static boolean isDemoted(String comm) {
        for (String p : DEMOTE) if (comm.startsWith(p)) return true;
        return false;
    }

    private static String readComm(File f) {
        try { return Files.readString(f.toPath()).trim(); } catch (Throwable t) { return null; }
    }

    private static void fail(String why) {
        failures++;
        PocketBoost.LOG.warn("[PocketBoost] scheduler problem ({}/3): {}", failures, why);
        if (failures >= 3) {
            disabled = true;
            PocketBoost.LOG.warn("[PocketBoost] scheduler disabled for this session");
        }
    }

    private CoreScheduler() {}
}
