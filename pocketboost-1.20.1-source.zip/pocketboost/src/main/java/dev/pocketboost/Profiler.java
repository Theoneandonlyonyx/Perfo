package dev.pocketboost;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/** Tells you what is actually eating the phone: GC share + busiest thread groups. Read-only. */
public final class Profiler {
    private static long lastWall, lastGc;
    private static final Map<Long, Long> lastCpu = new HashMap<>();
    private static int warnCooldown;

    public static void start() {
        ThreadMXBean tmx = ManagementFactory.getThreadMXBean();
        boolean cpuOk = tmx.isThreadCpuTimeSupported();
        if (cpuOk) { try { tmx.setThreadCpuTimeEnabled(true); } catch (Throwable ignored) { cpuOk = false; } }
        final boolean useCpu = cpuOk;
        ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "PocketBoost-Profiler");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
        });
        lastWall = System.nanoTime();
        lastGc = gcMillis();
        ses.scheduleWithFixedDelay(() -> {
            try {
                if (PBConfig.PROFILER_ENABLED.get()) sample(tmx, useCpu);
            } catch (Throwable t) {
                PocketBoost.LOG.debug("[PocketBoost] sample failed: {}", t.toString());
            }
        }, 60, Math.max(10, readInterval()), TimeUnit.SECONDS);
    }

    private static int readInterval() {
        try { return PBConfig.PROFILE_SECONDS.get(); } catch (Throwable t) { return 30; }
    }

    private static long gcMillis() {
        long s = 0;
        for (GarbageCollectorMXBean g : ManagementFactory.getGarbageCollectorMXBeans()) s += Math.max(0, g.getCollectionTime());
        return s;
    }

    private static void sample(ThreadMXBean tmx, boolean useCpu) {
        long now = System.nanoTime();
        long wallNs = now - lastWall;
        lastWall = now;
        long gc = gcMillis();
        double gcPct = (gc - lastGc) * 1_000_000.0 / wallNs * 100.0;
        lastGc = gc;

        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) >> 20;
        long maxMb = rt.maxMemory() >> 20;

        String top = "n/a";
        if (useCpu) {
            Map<String, Long> bucket = new HashMap<>();
            for (long id : tmx.getAllThreadIds()) {
                long cpu = tmx.getThreadCpuTime(id);
                if (cpu < 0) continue;
                Long prev = lastCpu.put(id, cpu);
                if (prev == null) continue;
                java.lang.management.ThreadInfo ti = tmx.getThreadInfo(id);
                if (ti == null) continue;
                bucket.merge(ti.getThreadName().replaceAll("\\d+", "#"), cpu - prev, Long::sum);
            }
            top = bucket.entrySet().stream()
                    .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                    .limit(5)
                    .map(e -> String.format("%s %.0f%%", e.getKey(), e.getValue() * 100.0 / wallNs))
                    .collect(Collectors.joining(" | "));
        }
        PocketBoost.LOG.info("[PocketBoost] GC {}% | heap {}/{} MB | busiest (100% = one core): {}", String.format("%.1f", gcPct), usedMb, maxMb, top);

        if (warnCooldown > 0) warnCooldown--;
        if (gcPct > PBConfig.GC_WARN_PERCENT.get() && warnCooldown == 0) {
            PocketBoost.LOG.warn("[PocketBoost] GC is using {}% of wall time with a {} MB heap. The heap is too small for this pack; raise the launcher's RAM allocation before blaming any mod.", String.format("%.0f", gcPct), maxMb);
            warnCooldown = 10;
        }
    }

    private Profiler() {}
}
