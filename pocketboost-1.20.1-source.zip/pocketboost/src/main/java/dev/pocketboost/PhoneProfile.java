package dev.pocketboost;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Finds which CPU cores this process may use and which of them are the fast ("big") ones. */
public final class PhoneProfile {
    public static int logical, allowed, big;
    public static int[] bigCpus = new int[0];
    public static String source = "assumed";

    public static void init() {
        logical = Runtime.getRuntime().availableProcessors();
        List<Integer> cpus = readAllowed();
        allowed = cpus.isEmpty() ? logical : cpus.size();
        big = allowed;
        if (cpus.size() > 1) {
            long[] f = new long[cpus.size()];
            long min = Long.MAX_VALUE, max = 0;
            boolean ok = true;
            for (int i = 0; i < f.length; i++) {
                f[i] = readLong("/sys/devices/system/cpu/cpu" + cpus.get(i) + "/cpufreq/cpuinfo_max_freq");
                if (f[i] <= 0) { ok = false; break; }
                min = Math.min(min, f[i]);
                max = Math.max(max, f[i]);
            }
            if (ok) {
                source = "cpufreq";
                if (max > min * 1.15) {
                    List<Integer> b = new ArrayList<>();
                    for (int i = 0; i < f.length; i++) if (f[i] >= max * 0.85) b.add(cpus.get(i));
                    bigCpus = b.stream().mapToInt(Integer::intValue).toArray();
                    big = bigCpus.length;
                }
            } else if (allowed == 8 && cpus.contains(6) && cpus.contains(7)) {
                source = "assumed 2+6 (sysfs unreadable)";
                bigCpus = new int[] {6, 7};
                big = 2;
            }
        }
        PocketBoost.LOG.info("[PocketBoost] cores: jvm={} allowed={} big={} {} (via {})",
                logical, allowed, big, java.util.Arrays.toString(bigCpus), source);
    }

    private static List<Integer> readAllowed() {
        List<Integer> out = new ArrayList<>();
        try {
            for (String line : Files.readAllLines(Path.of("/proc/self/status"))) {
                if (line.startsWith("Cpus_allowed_list:")) {
                    for (String part : line.substring(18).trim().split(",")) {
                        String[] r = part.trim().split("-");
                        int a = Integer.parseInt(r[0]);
                        int z = r.length > 1 ? Integer.parseInt(r[1]) : a;
                        for (int c = a; c <= z; c++) out.add(c);
                    }
                    break;
                }
            }
        } catch (Throwable ignored) { out.clear(); }
        return out;
    }

    private static long readLong(String p) {
        try { return Long.parseLong(Files.readString(Path.of(p)).trim()); } catch (Throwable t) { return -1; }
    }

    private PhoneProfile() {}
}
