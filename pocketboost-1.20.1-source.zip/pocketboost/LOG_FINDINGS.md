# What your latestlog.txt shows (SM-A715F, Adreno 618, 5524 MB RAM)

1. Heap is the bottleneck. RAM allocated 2064 MB. 174 GCs during startup, startup+world = 620 s,
   server ticks 27 s / 31 s / 42 s / 54 s behind. The thread dumps catch the server thread doing
   trivial work, i.e. the JVM is stalled by GC, not by that code. Raise allocation to ~3000-3300 MB.
2. TheFastLaunch's AdaptiveGovernor fired "Level 3 Critical Memory Pressure ... Emergency Eviction" 10 times
   and "Level 2" 3 times. Its message prints `{:.1f}` unformatted (a bug), and eviction/compaction on a thrashing
   heap adds work. After raising RAM, check whether it still fires.
3. Overlapping perf mods: canary and laglessmod both overwrite Mth sin/cos (logged conflict, one is skipped);
   lagless + laglessmod; BadOptimizations + modernfix + ferritecore + canary; memguard + memoryleakfix +
   alltheleaks + FastLaunch governor all doing memory work. ImmediatelyFast is the 1.20.4 file on 1.20.1.
   Fewer overlapping mods = fewer mixins = less startup heap. Test removing one at a time.
4. Embeddium is already "tainted" by fusion and sodiumdynamiclights mixing into BlockRenderer, LightDataAccess,
   WorldSlice. Oculus will hook the same area. Test Oculus with those two removed first if shaders misbehave.
5. Connector + Fabric API (74 jar-in-jar libs) is loaded. Find which mod needs it; if none you use, it is dead weight.
6. 16 resource packs; CTM-Overhaul spams invalid-path errors; a pack lacks metadata. Fewer packs = less load heap.
7. MixinHelper is installed and logs errors reading MixinConfig fields; remove unless you set it up on purpose.
8. Shaders: GPU-bound on Adreno via LTW. Start with a lightweight pack, low shadow resolution/distance.
