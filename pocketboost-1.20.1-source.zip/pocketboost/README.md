# PocketBoost 1.20.1 (Forge 47.4.5) — source, NOT compiled or tested

I had no Forge/Minecraft jars or network where I wrote this, so it has never been built or run.
Expect to fix a compile error or two. It is small (5 files) on purpose.

## Build
- PC: JDK 17, Gradle 8.1.1 -> `gradle build` -> `build/libs/pocketboost-1.20.1-1.0.0.jar`
- No PC: push this folder to a GitHub repo; the included Actions workflow builds the jar (Actions tab -> artifact).

## What it does (all toggles in config/pocketboost.toml)
0. CoreScheduler (the main one): your SD730 has 2 fast cores and 6 slow ones, and your pack runs ~40 worker
   threads. PC mods assume all cores are equal. This pins "Render thread" and "Server thread" to the 2 big
   cores and lowers the priority (nice +6) of chunk-build / world-gen / ForkJoin / FastLaunch workers, so a frame
   or a tick never loses a fight with a worker on the same core. It uses /system/bin/taskset and renice, which any
   app may run on its own threads. Nothing persists after the game closes. Check latest.log for
   "[PocketBoost] scheduler pass 1" - it prints what the shell answered. If it says "not found" or
   "not permitted", your Android/launcher blocks it and the mod turns itself off after 3 tries.
1. Governor: if frames run ~15% slower than your target FPS, entity render distance drops 0.25 at a time (floor 0.5).
   After ~10 s of comfortable frames it climbs back. Your own value is restored when you leave the world.
   Does not touch shaders, chunks, render distance, or any mod.
2. Profiler: every 30 s logs GC % of wall time, heap used/max, and the 5 busiest thread groups
   (100% = one core). This tells you which mod is burning the phone. Warns when GC > 10%.
3. Core probe: logs how many cores the process may use and how many are big.

## What it cannot do
- It cannot move shader/pixel work to the CPU. That would be far slower than the Adreno 618.
- It cannot change heap size or JVM flags. That is the launcher.
- It does not replace TheFastLaunch's shared workers; you already have those.
